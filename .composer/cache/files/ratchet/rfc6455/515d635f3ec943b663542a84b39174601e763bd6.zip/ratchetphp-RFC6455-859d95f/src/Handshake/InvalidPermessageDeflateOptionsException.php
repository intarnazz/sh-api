<?php

namespace Ratchet\RFC6455\Handshake;

class InvalidPermessageDeflateOptionsException extends \Exception
{
}